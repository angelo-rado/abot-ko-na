export default function Loading() {
  return (
    <div className="max-w-xl mx-auto p-6 text-center text-muted-foreground">
      Loading family…
    </div>
  )
}
