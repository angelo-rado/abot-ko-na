'use client'

export { default } from '../settings/page'
export const dynamic = 'force-dynamic'
