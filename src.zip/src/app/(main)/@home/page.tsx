'use client'
export { default } from '../page'
export const dynamic = 'force-dynamic'
