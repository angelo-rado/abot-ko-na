// Mounts the invite/join page into the @family slot
export { default } from '@/app/(main)/family/join/page';
