'use client'
// This file mounts the existing family detail page into the @family slot
export { default } from '@/app/(main)/family/[id]/page'
