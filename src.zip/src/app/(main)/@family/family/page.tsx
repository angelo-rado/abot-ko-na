'use client'
// This file mounts the existing family index into the @family slot
export { default } from '@/app/(main)/family/page'
