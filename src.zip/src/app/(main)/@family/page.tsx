'use client'
export { default } from '../family/page'
export const dynamic = 'force-dynamic'
