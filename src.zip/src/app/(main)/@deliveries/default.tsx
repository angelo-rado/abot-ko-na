'use client'

export default function DefaultDeliveries() { return null; }
