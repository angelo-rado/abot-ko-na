'use client'

export { default } from '../deliveries/page'
export const dynamic = 'force-dynamic'
