'use client';

import { useEffect, useMemo, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { firestore } from '@/lib/firebase';
import { useSelectedFamily } from '@/lib/selected-family';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

/**
 * DefaultFamilySelector
 * - Shows the user's default family by NAME (never the raw UID).
 * - If the provider hasn't loaded family names yet, we best-effort fetch the selected family's name.
 * - Lets the user change or clear their default; persists via useSelectedFamily().setFamilyId.
 */
export default function DefaultFamilySelector() {
  const { families, loadingFamilies, familyId, setFamilyId } = useSelectedFamily();

  // Resolved display name for the currently selected family
  const providerName = useMemo(() => {
    if (!familyId) return null;
    const f = families.find((x) => x.id === familyId);
    return f?.name ?? null;
  }, [families, familyId]);

  const [resolvedName, setResolvedName] = useState<string | null>(null);
  const [loadingName, setLoadingName] = useState(false);

  // If provider didn't give us a name for the selected id yet, fetch it once.
  useEffect(() => {
    let cancelled = false;
    async function ensureName() {
      setResolvedName(null);
      if (!familyId) return;
      if (providerName) {
        setResolvedName(providerName);
        return;
      }
      try {
        setLoadingName(true);
        const snap = await getDoc(doc(firestore, 'families', familyId));
        if (cancelled) return;
        if (snap.exists()) {
          const data = snap.data() as any;
          const name = typeof data?.name === 'string' ? data.name : null;
          setResolvedName(name);
        } else {
          setResolvedName(null);
        }
      } catch {
        setResolvedName(null);
      } finally {
        if (!cancelled) setLoadingName(false);
      }
    }
    ensureName();
    return () => { cancelled = true };
  }, [familyId, providerName]);

  const display = resolvedName ?? providerName ?? (familyId ? 'Untitled family' : null);

  const handleChange = async (id: string) => {
    // Persist selection (or clear with empty string)
    try {
      await setFamilyId(id || null);
      toast.success('Default family updated');
    } catch {
      toast.error('Failed to update default family');
    }
  };

  // Loading skeleton if we haven't determined anything yet and no selection
  if (loadingFamilies && !familyId) {
    return (
      <div className="space-y-2">
        <Label className="text-sm">Default family</Label>
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }

  // Build items list sorted by name (fallback to id for stable order)
  const items = useMemo(() => {
    const copy = [...families];
    copy.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
    return copy;
  }, [families]);

  return (
    <div className="space-y-2">
      <Label className="text-sm">Default family</Label>
      <Select
        value={familyId ?? ''}
        onValueChange={(val) => handleChange(val)}
      >
        <SelectTrigger className="w-full">
          <SelectValue placeholder={loadingName ? 'Loading…' : (display ?? 'Select a family')} />
        </SelectTrigger>
        <SelectContent>
          <SelectItem key="__none" value="">
            <span className="text-muted-foreground">— None —</span>
          </SelectItem>
          {items.map((f) => (
            <SelectItem key={f.id} value={f.id}>
              {f.name || 'Untitled family'}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <p className="text-xs text-muted-foreground">
        This sets your default family used across Home and Deliveries. You can still browse others from their pages.
      </p>
    </div>
  );
}
